package com.example.examen;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText editText1, editText2;
    private Button button;
    private TextView textView;
    public int intentos = 3;
    public String Nombre = "Usuario1";
    public String Contraseña = "123456789";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.TextViewName);
        editText2 = findViewById(R.id.TextViewPassword);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.TexrAlert);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String texto1 = editText1.getText().toString();
                String texto2 = editText2.getText().toString();

                if (verificarTextoEnArray(texto1, texto2)==true && cantidad()==true && cantidadCon()==true) {
                    textView.setText("Ingreso correctamente");


                } else {
                    intentos = intentos - 1;
                    if (intentos > 0) {
                        textView.setText("El usuario ingresado o contraseña ingresado es incorrecto, le quedan " + intentos + " intentos");
                    } else {
                        textView.setText("ya no le quedan más intentos");
                        button.setEnabled(false);

                    }

                }
            }
        });

    }

    private boolean verificarTextoEnArray(String texto1, String texto2) {
            if (Nombre.contains(texto1) && Contraseña.contains(texto2)) {
                return true;
            }
                return false;
    }
    private boolean cantidad() {
        for(int i=0; i<Nombre.length(); i++) {
            if (i > 6) {
                return true;
            }
        }
        return false;
    }
    private boolean cantidadCon() {
        for(int i=0; i<Contraseña.length(); i++) {
            if (i > 8) {
                return true;
            }
        }
        return false;
    }
    public static boolean esMayuscula(String texto1) {
        return texto1.equals(texto1.toUpperCase());
    }

}
